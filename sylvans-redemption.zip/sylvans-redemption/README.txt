Sylvan's Redemption Prototype

CONTROLS

JUMP: up, w
LEFT: left, a
RIGHT: right, d
POSSESS: right shift, e

MOVEMENTS

SYLVAN: glide (hold JUMP while falling)
SPIDER: climb walls (hold JUMP next to a wall)
BAT: fly (hold JUMP)

Sylvan can possess an enemy for 5 seconds. Use these enemies to get to different parts of the level.
To possess an enemy, ensure that Sylvan is within close range of that enemy. Currently, the bat has priority over the spider.
If Sylvan hits an enemy, he will be knocked back. 