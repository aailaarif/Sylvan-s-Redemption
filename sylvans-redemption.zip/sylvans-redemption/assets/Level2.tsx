<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Level2" tilewidth="16" tileheight="16" tilecount="300" columns="25">
 <image source="Scaffolding_and_BG_Parts (16 x 16).png" width="400" height="192"/>
</tileset>
