<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Level2Ground" tilewidth="16" tileheight="16" tilecount="726" columns="33">
 <image source="Gray_Tile_Terrain (16 x 16).png" width="528" height="352"/>
</tileset>
