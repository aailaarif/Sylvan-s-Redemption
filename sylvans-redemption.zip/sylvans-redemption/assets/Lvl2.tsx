<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Lvl2" tilewidth="800" tileheight="800" tilecount="26" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="1" x="0" y="0" width="16" height="16">
  <image width="96" height="96" source="Game-Asset-Carol-Salvato/tile-set-ground-earth-rock-grass.png"/>
 </tile>
 <tile id="2">
  <image width="96" height="96" source="Game-Asset-Carol-Salvato/tile-set-ground-earth-rock-sombra.png"/>
 </tile>
 <tile id="3">
  <image width="800" height="800" source="Game-Asset-Carol-Salvato/todos-objetos-hcs.png"/>
 </tile>
 <tile id="12">
  <image width="64" height="32" source="Game-Asset-Carol-Salvato/rock-01-a.png"/>
 </tile>
 <tile id="13">
  <image width="64" height="32" source="Game-Asset-Carol-Salvato/rock-01-b.png"/>
 </tile>
 <tile id="14">
  <image width="32" height="32" source="Game-Asset-Carol-Salvato/tileset-cave-01.png"/>
 </tile>
 <tile id="15">
  <image width="96" height="96" source="Game-Asset-Carol-Salvato/tile-set-ground-earth-rock.png"/>
 </tile>
 <tile id="16">
  <image width="32" height="32" source="Game-Asset-Carol-Salvato/Barrel-pixel-oleo.png"/>
 </tile>
 <tile id="26">
  <image width="96" height="64" source="Game-Asset-Carol-Salvato/wather-green-01.png"/>
 </tile>
</tileset>
