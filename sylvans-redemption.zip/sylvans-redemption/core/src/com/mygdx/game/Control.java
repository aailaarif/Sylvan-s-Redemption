package com.mygdx.game;

/*
Anjali Narang
Aaila Arif
Jenna Esposito
 */

public enum Control { // what key presses can mean
    UP, DOWN, LEFT, RIGHT, POSSESS, SELECT
}
